# Robyn Buamann
# AST4762 P6 and HW9
# October 22, 2026

# import necessary libraries
import os
import numpy as np
import matplotlib.pyplot as plt
from astropy.io import fits
from hw9_rab_support_functions import disk
from hw8_rab import *
import pwd
import time 

# start practicum work:
print('\n Practicum 6:\n')

# start problem 1:
print('Problem1:')

# create test disk mask
test_disk = disk(6.2, (12.3, 14.5), (25, 30))

# save test disk
fits.writeto('disktest.fits', test_disk.astype(np.uint8), overwrite=True)

# check requested pixels:
print('The pixel [14, 14] is: ', test_disk[14, 14])
print('The pixel [2, 1] is: ',   test_disk [2, 1])

# start problem 2: 
print('\nProblem 2:')

# part a
# lists to store the data of lampon/lamp off data
lamp_on  = []
lamp_off = []

# populate the lists with loops
for filename in os.listdir(datadir):
    if 'k_lampon' in filename and filename.endswith(fext):
        lamp_on.append(filename)
    if 'k_lampoff' in filename and filename.endswith(fext):
        lamp_off.append(filename)

# sort the data to be alphabetical/number order
lamp_on.sort()
lamp_off.sort()

# save number of each file and size of file
n_on  = len(lamp_on)
n_off = len(lamp_off)
nx, ny = fits.getdata(datadir + lamp_on[0]).shape

# create arrays to hold data
lamp_on_arr  = np.zeros( (n_on, ny, nx),  dtype = np.float64 )
lamp_off_arr = np.zeros( (n_off, ny, nx), dtype = np.float64 )

#populate the arrays
for i in range(n_on):
    lamp_on_arr[i] = fits.getdata(datadir + lamp_on[i])

for i in range(n_off):
    lamp_off_arr[i] = fits.getdata(datadir + lamp_off[i])

# median combine the two 
lamp_on_med  = np.median(lamp_on_arr,  axis = 0)
lamp_off_med = np.median(lamp_off_arr, axis = 0)

# suptract the two
flat = lamp_on_med - lamp_off_med

#create normalization factor
flat_norm_reg = flat[norm_region[0][0]:norm_region[1][0],
                     norm_region[0][1]:norm_region[1][1]]

flat_factor   = np.median(flat_norm_reg)

# normalize
flat_norm = flat/flat_factor

# renew header
head["History"] = ('File Created. ' + time.strftime('%a %b %d %H:%M:%S %Z %Y ') \
                   + username)

#save to fits file
fits.writeto('flat.fits', flat_norm, header = head, overwrite=True)

# print the value of pixel index [217, 184]
print('Pixel [217,184] of the flat field is', flat_norm[217,184])

# part b: Apply the flat field to all the sky-subtracted object data
print('Number of zero pixels:', np.sum(flat_norm == 0))
#should we change those to NaN?
#flat_norm[flat_norm == 0] = np.nan
corr_sky = sky_sub_dat / flat_norm

# print the value of pixel index [217, 184]
print('Pixel [217,184] of the corrected sky frames are', corr_sky[:,217,184])

# write to fits file
fits.writeto('stars_13s_9_flat.fits', corr_sky[-1], header = head, overwrite=True)